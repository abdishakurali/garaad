import {
    a as O,
    u as A,
    b as B,
    j as n,
    P as w,
    f as R,
    d as H,
    E as K
} from "./ui-vendor.Bl07kmxE.js";
import {
    r as s
} from "./react-vendor.CoFnG1Cb.js";
import {
    j as L,
    c as j
} from "./index.DrC_YY1K.js";
import {
    l as q
} from "./icons-vendor.BaRxkmJj.js";
var g = "Checkbox",
    [z, W] = O(g),
    [T, X] = z(g),
    N = s.forwardRef((e, i) => {
        const {
            __scopeCheckbox: t,
            name: u,
            checked: p,
            defaultChecked: o,
            required: h,
            disabled: d,
            value: m = "on",
            onCheckedChange: x,
            form: l,
            ...C
        } = e, [a, k] = s.useState(null), v = A(i, r => k(r)), y = s.useRef(!1), P = a ? l || !!a.closest("form") : !0, [f = !1, E] = B({
            prop: p,
            defaultProp: o,
            onChange: x
        }), M = s.useRef(f);
        return s.useEffect(() => {
            const r = a == null ? void 0 : a.form;
            if (r) {
                const b = () => E(M.current);
                return r.addEventListener("reset", b), () => r.removeEventListener("reset", b)
            }
        }, [a, E]), n.jsxs(T, {
            scope: t,
            state: f,
            disabled: d,
            children: [n.jsx(w.button, {
                type: "button",
                role: "checkbox",
                "aria-checked": c(f) ? "mixed" : f,
                "aria-required": h,
                "data-state": _(f),
                "data-disabled": d ? "" : void 0,
                disabled: d,
                value: m,
                ...C,
                ref: v,
                onKeyDown: R(e.onKeyDown, r => {
                    r.key === "Enter" && r.preventDefault()
                }),
                onClick: R(e.onClick, r => {
                    E(b => c(b) ? !0 : !b), P && (y.current = r.isPropagationStopped(), y.current || r.stopPropagation())
                })
            }), P && n.jsx(F, {
                control: a,
                bubbles: !y.current,
                name: u,
                value: m,
                checked: f,
                required: h,
                disabled: d,
                form: l,
                style: {
                    transform: "translateX(-100%)"
                },
                defaultChecked: c(o) ? !1 : o
            })]
        })
    });
N.displayName = g;
var S = "CheckboxIndicator",
    I = s.forwardRef((e, i) => {
        const {
            __scopeCheckbox: t,
            forceMount: u,
            ...p
        } = e, o = X(S, t);
        return n.jsx(H, {
            present: u || c(o.state) || o.state === !0,
            children: n.jsx(w.span, {
                "data-state": _(o.state),
                "data-disabled": o.disabled ? "" : void 0,
                ...p,
                ref: i,
                style: {
                    pointerEvents: "none",
                    ...e.style
                }
            })
        })
    });
I.displayName = S;
var F = e => {
    const {
        control: i,
        checked: t,
        bubbles: u = !0,
        defaultChecked: p,
        ...o
    } = e, h = s.useRef(null), d = L(t), m = K(i);
    s.useEffect(() => {
        const l = h.current,
            C = window.HTMLInputElement.prototype,
            k = Object.getOwnPropertyDescriptor(C, "checked").set;
        if (d !== t && k) {
            const v = new Event("click", {
                bubbles: u
            });
            l.indeterminate = c(t), k.call(l, c(t) ? !1 : t), l.dispatchEvent(v)
        }
    }, [d, t, u]);
    const x = s.useRef(c(t) ? !1 : t);
    return n.jsx("input", {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: p ? ? x.current,
        ...o,
        tabIndex: -1,
        ref: h,
        style: { ...e.style,
            ...m,
            position: "absolute",
            pointerEvents: "none",
            opacity: 0,
            margin: 0
        }
    })
};

function c(e) {
    return e === "indeterminate"
}

function _(e) {
    return c(e) ? "indeterminate" : e ? "checked" : "unchecked"
}
var D = N,
    $ = I;
const G = s.forwardRef(({
    className: e,
    ...i
}, t) => n.jsx(D, {
    ref: t,
    className: j("peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", e),
    ...i,
    children: n.jsx($, {
        className: j("flex items-center justify-center text-current"),
        children: n.jsx(q, {
            className: "h-4 w-4"
        })
    })
}));
G.displayName = D.displayName;
export {
    G as C
};