import {
    r as c
} from "./react-vendor.CoFnG1Cb.js";
var f = "@vercel/analytics",
    v = "1.4.1",
    w = () => {
        window.va || (window.va = function(...t) {
            (window.vaq = window.vaq || []).push(t)
        })
    };

function d() {
    return typeof window < "u"
}

function l() {
    try {
        const e = "production"
    } catch {}
    return "production"
}

function m(e = "auto") {
    if (e === "auto") {
        window.vam = l();
        return
    }
    window.vam = e
}

function s() {
    return (d() ? window.vam : l()) || "production"
}

function u() {
    return s() === "production"
}

function a() {
    return s() === "development"
}

function b(e, {
    [e]: t,
    ...r
}) {
    return r
}

function h(e, t) {
    if (!e) return;
    let r = e;
    const n = [];
    for (const [i, o] of Object.entries(e)) typeof o == "object" && o !== null && (t.strip ? r = b(i, r) : n.push(i));
    if (n.length > 0 && !t.strip) throw Error(`The following properties are not valid: ${n.join(", ")}. Only strings, numbers, booleans, and null are allowed.`);
    return r
}
var y = "https://va.vercel-scripts.com/v1/script.debug.js",
    g = "/_vercel/insights/script.js";

function k(e = {
    debug: !0
}) {
    var t;
    if (!d()) return;
    m(e.mode), w(), e.beforeSend && ((t = window.va) == null || t.call(window, "beforeSend", e.beforeSend));
    const r = e.scriptSrc || (a() ? y : g);
    if (document.head.querySelector(`script[src*="${r}"]`)) return;
    const n = document.createElement("script");
    n.src = r, n.defer = !0, n.dataset.sdkn = f + (e.framework ? `/${e.framework}` : ""), n.dataset.sdkv = v, e.disableAutoTrack && (n.dataset.disableAutoTrack = "1"), e.endpoint && (n.dataset.endpoint = e.endpoint), e.dsn && (n.dataset.dsn = e.dsn), n.onerror = () => {
        const i = a() ? "Please check if any ad blockers are enabled and try again." : "Be sure to enable Web Analytics for your project and deploy again. See https://vercel.com/docs/analytics/quickstart for more information.";
        console.log(`[Vercel Web Analytics] Failed to load script from ${r}. ${i}`)
    }, a() && e.debug === !1 && (n.dataset.debug = "false"), document.head.appendChild(n)
}

function E(e, t, r) {
    var n, i;
    if (!d()) {
        const o = "[Vercel Web Analytics] Please import `track` from `@vercel/analytics/server` when using this function in a server environment";
        if (u()) console.warn(o);
        else throw new Error(o);
        return
    }
    if (!t) {
        (n = window.va) == null || n.call(window, "event", {
            name: e,
            options: r
        });
        return
    }
    try {
        const o = h(t, {
            strip: u()
        });
        (i = window.va) == null || i.call(window, "event", {
            name: e,
            data: o,
            options: r
        })
    } catch (o) {
        o instanceof Error && a() && console.error(o)
    }
}

function S({
    route: e,
    path: t
}) {
    var r;
    (r = window.va) == null || r.call(window, "pageview", {
        route: e,
        path: t
    })
}

function P(e) {
    return c.useEffect(() => {
        var t;
        e.beforeSend && ((t = window.va) == null || t.call(window, "beforeSend", e.beforeSend))
    }, [e.beforeSend]), c.useEffect(() => {
        k({
            framework: e.framework || "react",
            ...e.route !== void 0 && {
                disableAutoTrack: !0
            },
            ...e
        })
    }, []), c.useEffect(() => {
        e.route && e.path && S({
            route: e.route,
            path: e.path
        })
    }, [e.route, e.path]), null
}
export {
    P as Analytics, E as track
};